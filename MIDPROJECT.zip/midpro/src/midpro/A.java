package midpro;


public class A {
	
	//attribute
	private String nama, kode, jk, jabatan;

	private double gaji;

	
	//constructor
	//keyword "this" untuk menandakan bahwa variable itu mengacu pada attribute yang ada dikelasnya
	public A(String nama, String kode, String jk, String jabatan, double gaji) {
		this.nama = nama;
		this.kode = kode;
		this.jk = jk;
		this.jabatan = jabatan;
	
		this.gaji = gaji;
	}
 void display() {
		
		System.out.println("---------------------------------------------------------------------------------------------");  
		System.out.printf("| %15s | %15s | %20s | %10s | %10s |", "Kode Karyawan", "Nama Karyawan", "Jenis Kelamin", "Jabatan", "Gaji"); 
		System.out.println();  
		System.out.println("---------------------------------------------------------------------------------------------");  
		System.out.format("| %15s | %15s | %20s | %10s | %10s |", nama,kode,jk,jabatan,gaji);  
		System.out.println();  
		System.out.println("---------------------------------------------------------------------------------------------");
		
		 
		  
}
	
		
	
	
	
	
	

	public String getnama() {
		return nama;
	}

	public void setnama(String nama) {
		this.nama = nama;
	}

	public String getkode() {
		return kode;
	}

	public void setkode(String kode) {
		this.kode = kode;
	}

	public String getjk() {
		return jk;
	}

	public void setjk(String jk) {
		this.jk = jk;
	}

	public String getjabatan() {
		return jabatan;
	}

	public void setjabatan(String jabatan) {
		this.jabatan = jabatan;
	}

	

	public double getgaji() {
		return gaji;
	}

	public void setgaji(double gaji) {
		this.gaji = gaji;
	}






















		
		
	

	
	
}