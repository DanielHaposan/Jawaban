package midpro;

import java.util.Comparator;
import java.util.Scanner;
import java.util.Vector;




public class PROJECT {
	Scanner sc = new Scanner(System.in);
	Vector<A> data = new Vector<A>();
	
	public static void main(String[] args) {
		new PROJECT();
	}

	void clear() {
		for(int x=0;x<30;x++) System.out.println("");
	}

	int show() {
		int counter=0;
		for(int x=0;x<data.size();x++) {
			System.out.println((counter+1) + ". " + data.get(x).getnama());
			counter++;
		}
		return counter;
	}

		


	void updateKaryawan() {
		clear();
		int counter = 0;
		System.out.println("Data Karyawan");
		System.out.println("^^^^^^^^^^^^^^^^^");
		if(data.isEmpty()) {
			System.out.println("Data Kosong");
			System.out.println("^^^^^^^^^^^^^^^^^");
		}
		else {
			counter = show();
			System.out.println("^^^^^^^^^^^^^^^^^");
			
			int inp = 0;
			do {
				System.out.print("Input number to update [0 to exit]: ");
				inp = sc.nextInt();
				if(inp == 0) break;
			} while(inp != 0 && inp > counter);
			
			if(inp != 0) {
				int idx = inp-1;
				
				
				String nama = data.get(idx).getnama();
				String kode = data.get(idx).getkode();
				
				String jk = data.get(idx).getjk();
				String jabatan = data.get(idx).getjabatan();
				double gaji = data.get(idx).getgaji();


				
				


				
				String namaS, kodeS, jkS;
		
				double gajiS;
				
				System.out.println("Input [0] to skip!");
				sc.nextLine();
				System.out.print("Input nama: "); namaS = sc.nextLine();
				System.out.print("Input kode: "); kodeS = sc.nextLine();
				
				System.out.print("Input jk: "); jkS = sc.nextLine();
				System.out.print("Input gaji: "); gajiS = sc.nextDouble();
				
				
				
				
				//ngecek apakah inputan user itu = 0
				if(!namaS.equals("0")) nama = namaS;
				if(!kodeS.equals("0")) kode = kodeS;
				
				if(!jkS.equals("0")) jk = jkS;
				if(gajiS != 0) gaji = gajiS;
				



				//ubah data yang baru ini ke dalam vector
				System.out.println("Update Successfully!");
			}
		}
	}
	
	
	void sortBygaji() {
		data.sort(new Comparator<>() {
			//sorting gaji ascending
			public int compare(A a, A b) {
				if(a.getgaji() == b.getgaji()) return 0;
				else if(a.getgaji() < b.getgaji()) return 1;
				else return -1;
}
			
			
			
		});
	}
	
	void viewKaryawan() { 
		clear();
		sortBygaji();
		int counter = 0;
		System.out.println("Data Karyawan");
		System.out.println("^^^^^^^^^^^^^^^^^");
		if(data.isEmpty()) {
			System.out.println("Data Kosong");
			System.out.println("^^^^^^^^^^^^^^^^^");
		}
		else {
			counter = show();
			System.out.println("^^^^^^^^^^^^^^^^^");
			
			int inp = 0;
			do {
				System.out.print("Input number to view details [0 to exit]: ");
				inp = sc.nextInt();
				
				if(inp == 0) break;
			} while(inp != 0 && inp > counter);
			
			if(inp != 0) {
				int tempInt = inp-1;
				data.get(tempInt).display();
			}
		}
	}

	void deleteKaryawan() {
		clear();
		int counter = 0;
		System.out.println("Data Karyawan");
		System.out.println("^^^^^^^^^^^^^^^^^");
		if(data.isEmpty()) {
			System.out.println("Data Kosong");
			System.out.println("^^^^^^^^^^^^^^^^^");
		}
		else {
			counter = show();
			System.out.println("^^^^^^^^^^^^^^^^^");
			
			int inp = 0;
			do {
				System.out.print("Input number to delete [0 to exit]: ");
				inp = sc.nextInt();
				
				if(inp == 0) break;
			} while(inp != 0 && inp > counter);
			
			if(inp != 0) {						
				int idx = inp-1;
				
				data.get(idx).display();
				
				String validation = "";
				sc.nextLine();
				do {
					System.out.print("Are you sure to delete this data? (Y|N): "); validation = sc.nextLine();
				} while(!validation.equals("Y") && !validation.equals("N"));
				
				if(validation.equals("Y")) {
					System.out.println(data.get(idx).getnama()+ " has been delete!");
					data.remove(idx);
				}
			}
		}
	}

	void insertKaryawan() {
		clear();
		String nama, kode, jk, jabatan;
	
		double gaji;
		
		sc.nextLine();
		System.out.print("Input Kode Karyawan: "); nama = sc.nextLine();
		System.out.print("Input Nama Karyawan: "); kode = sc.nextLine();
		
		
		do {
		System.out.print("Input Jenis Kelamin[Laki-Laki/Perempuan]: "); jk = sc.nextLine();
		} while(!jk.equals("Laki-Laki") && !jk.equals("Perempuan"));
		do {
			System.out.print("Input jabatan(Manager / Supervisor / Admin): "); jabatan = sc.nextLine();
		} while(!jabatan.equals("Manager") && !jabatan.equals("Supervisor")&& !jabatan.equals("Admin"));
		
		System.out.print("Input Gaji: "); gaji = sc.nextDouble();

		sc.nextLine();
		data.add(new A(nama, kode, jk, jabatan, gaji));
		

		System.out.println(nama + " has been added!");
	}

	public PROJECT() {
		
	
		
		int input = 0;
		do {
			clear();
			System.out.println("Data Karyawan");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("1. Insert Data Karyawan");
			System.out.println("2. View Data Karyawan");
			System.out.println("3. Update Data Karyawan");
			System.out.println("4. Delete Data Karyawan");
			System.out.println("5. Exit");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.print("Pilih Nomer: ");
		
			
			input = sc.nextInt();
			
			if(input == 1) {
				insertKaryawan();
				System.out.println("Enter to continue...");
				sc.nextLine(); sc.nextLine();
			}
			else if(input == 2) {
				viewKaryawan();
				System.out.println("enter to continue...");
				sc.nextLine(); sc.nextLine();
			}
			else if(input == 3) {
				updateKaryawan();
				System.out.println("enter to continue...");
				sc.nextLine(); sc.nextLine();
			}
			else if(input == 4) {
				deleteKaryawan();
				System.out.println("enter to continue...");
				sc.nextLine(); sc.nextLine();
			}
		} while(input != 5);
	}
	

		
		
	}

